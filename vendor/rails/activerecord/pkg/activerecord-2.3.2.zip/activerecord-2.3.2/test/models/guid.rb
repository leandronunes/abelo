class Guid < ActiveRecord::Base
end