require 'active_resource'
