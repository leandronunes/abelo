class Numeric
  def to_json(options = nil) #:nodoc:
    to_s
  end
end
