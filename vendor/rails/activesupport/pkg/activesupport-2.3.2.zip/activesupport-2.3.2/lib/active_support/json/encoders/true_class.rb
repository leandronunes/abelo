class TrueClass
  def to_json(options = nil) #:nodoc:
    'true'
  end
end
